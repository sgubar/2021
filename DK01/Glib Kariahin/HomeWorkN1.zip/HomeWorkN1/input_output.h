//
// Created by 123 on 04.02.2021.
//
#define _CRT_SECURE_NO_WARNINGS
#ifndef HOMEWORKN1_INPUT_H
#define HOMEWORKN1_INPUT_H
#include <stdio.h>
#include <string.h>

char* getAWord(int size);
void println(const char args_0[] );
void ln();
void printlnC(char word[],int size);

#endif //HOMEWORKN1_INPUT_H
