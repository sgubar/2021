//
// Created by GLIB on 05.02.2021.
//
#include <time.h>

char* getTime(){
    struct tm *ptr;
    time_t lt;
    lt = time(NULL);
    ptr = localtime(&lt);
    return asctime(ptr);

}
