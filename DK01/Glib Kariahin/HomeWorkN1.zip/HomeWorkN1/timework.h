//
// Created by GLIB on 06.02.2021.
//

#ifndef HOMEWORKN1_TIMEWORK_H
#define HOMEWORKN1_TIMEWORK_H

char* getTime();

#endif //HOMEWORKN1_TIMEWORK_H
