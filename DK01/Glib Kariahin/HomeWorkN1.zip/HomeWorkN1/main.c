#include <stdio.h>
#include "input_output.h"
#include "swapper.h"
#include "matrix.h"

int main() {


    println("Hello. It`s a  user-friendly interface.");
    println("Enter a string : ");
    //REFERENCE TO JAVA
    int size = 12;

    char word[size];

    char* raw = getAWord(size);
    for(int x = 0;x<size;x++){
        word[x]=*(raw+x);
        printf("%c",*(raw+x));
    }

    println("Operating ... ");


    int bytesOfWord = size*sizeof(char);
    printf("Bytes of input data : %iB",bytesOfWord);
    ln();
    printf("Size of input data : %i",size);
    ln();

    simpleSwap(word,size);

    printlnC(word,size);

    println("Clearing the memory...");
    delete_matrix_char(word);
    delete_matrix_char(raw);





//    //TODO aSK why sizeof dont normal work in the file input.c

}
