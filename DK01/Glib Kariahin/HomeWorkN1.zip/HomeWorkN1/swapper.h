//
// Created by 123 on 06.02.2021.
//

#ifndef HOMEWORKN1_SWAPPER_H
#define HOMEWORKN1_SWAPPER_H

void simpleSwap(char word[],int size);

#endif //HOMEWORKN1_SWAPPER_H
