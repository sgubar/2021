#include "matrix.h"
#include <stdlib.h>


//int matrix_sum(int **matrix, int row, int col)
//{
//    int result = -1;
//
//    if (matrix == NULL)
//    {
//        return result;
//    }
//
//    result = 0;
//
//    for (int i = 0; i < row; i++) {
//        for (int j = 0; j < col; j++) {
//            result += *(*(matrix + i) + j); // result = result + matrix[i][j];
//        }
//    }
//
//    return result;
//}

int matrix_sum1(int *matrix, int row, int col) {
    int result = -1;

    if (matrix == NULL)
    {
        return result;
    }

    for (int i = 0; i < row; i++) {
        for (int j = 0; j < col; j++) {
            result += *(matrix + i*col + j); // result = result + matrix[i][j]; ???
        }
    }

    result = 0;
    return result;
}

int **create_matrix(int row, int col)
{
    int **matrix = (int **)malloc(sizeof(int *) * row); // int *array[];

    for (int i = 0; i < row; i++) {
        *(matrix + i) = (int *)malloc(sizeof(int) * col); //void *
    }

    return matrix;
}

void delete_matrix(int **matrix, int row) {
    if (matrix == NULL) {
        return;
    }

    for (int i = 0; i < row; i++) {
        free (*(matrix + i));
    }

    free(matrix);
}

int *create_matrix1(int row, int col) {
    return (int *)malloc(sizeof(int) * row * col);
}

char *create_matrix_char(int row) {
    return (char *)malloc(sizeof(char) * row );
}
void delete_matrix_char(char *matrix) {
    if (matrix != NULL) {
        free(matrix);
    }
}
void delete_matrix1(int *matrix) {
    if (matrix != NULL) {
        free(matrix);
    }
}