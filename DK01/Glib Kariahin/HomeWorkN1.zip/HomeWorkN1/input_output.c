

#define _CRT_SECURE_NO_WARNINGS
#include <stdio.h>
#include "matrix.h"

const int MAX_STRING_SIZE_KB = 1024;
char* getAWord(int size){
    char* str = create_matrix_char(size);
    gets(str);
    return str;
}

void println(const char args_0[] ){
    puts(args_0);
    printf("%s","\n");
}

void ln(){
    printf("%s","\n");
}

void printlnC(char word[],int size){
    for(int x = 0;x<size;x++){
        printf("%c",word[x]);
    }
    ln();
}
void finalize(char message[]){

}
